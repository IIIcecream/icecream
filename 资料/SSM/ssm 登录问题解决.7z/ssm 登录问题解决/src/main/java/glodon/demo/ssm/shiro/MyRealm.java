package glodon.demo.ssm.shiro;

import glodon.demo.ssm.dao.mapper.ManagerMapper;
import glodon.demo.ssm.dao.pojo.ManagerBeam;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.realm.AuthenticatingRealm;
import org.springframework.beans.factory.annotation.Autowired;

import java.sql.*;


/**
 * Created by Administrator on 2018/11/2.
 */
public class MyRealm extends AuthenticatingRealm {
    SimpleAuthenticationInfo info = null;

    @Autowired
    ManagerMapper managerMapper;

    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken) throws AuthenticationException {
        String username = (String) authenticationToken.getPrincipal();

//        //访问数据库
//        try {
//            Class.forName("com.mysql.jdbc.Driver");
//            String url = "jdbc:mysql://localhost:3306/zhao";
//            Connection connection = DriverManager.getConnection(url, "root", "root");
//            PreparedStatement preparedStatement = connection.prepareStatement("select * from t_manager where username=?");
//            preparedStatement.setString(1, username);
//            ResultSet resultSet = preparedStatement.executeQuery();
//            if (resultSet.next()){
//                String password = resultSet.getString(3);
//                info = new SimpleAuthenticationInfo(username, password, this.getName());
//            }else{
//                throw new AuthenticationException();
//            }
//        } catch (ClassNotFoundException e) {
//            e.printStackTrace();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }

        ManagerBeam managerBeam = managerMapper.selectUserByName(username);
        if (managerBeam != null) {
            info = new SimpleAuthenticationInfo(username, managerBeam.getPassword(), this.getName());
        }else{
            throw new AuthenticationException();
        }
        return info;
    }
}
