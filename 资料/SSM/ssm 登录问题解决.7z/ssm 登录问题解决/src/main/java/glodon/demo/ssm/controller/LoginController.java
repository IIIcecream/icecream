package glodon.demo.ssm.controller;

import glodon.demo.ssm.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Created by Administrator on 2018/11/2.
 */
@Controller
public class LoginController {
    @Autowired
    private LoginService loginService;

    @RequestMapping("/login")
    public String doLogin(@RequestParam("username") String username,
                          @RequestParam("password") String password){
        return  loginService.doLogin(username, password);
    }

}
