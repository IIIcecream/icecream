package glodon.demo.ssm.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created by Administrator on 2018/11/1.
 */
@Controller
public class HolleController {

    @RequestMapping("/hello")
    public String hello(){
        return "home";
    }
}
