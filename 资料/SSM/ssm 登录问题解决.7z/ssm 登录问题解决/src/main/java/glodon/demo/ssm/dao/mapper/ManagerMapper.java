package glodon.demo.ssm.dao.mapper;

import glodon.demo.ssm.dao.pojo.ManagerBeam;

/**
 * Created by Administrator on 2018/11/2.
 */
public interface ManagerMapper {
    ManagerBeam selectUserByName(String username);
}
