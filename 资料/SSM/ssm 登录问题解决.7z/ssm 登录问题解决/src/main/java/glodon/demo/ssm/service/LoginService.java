package glodon.demo.ssm.service;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.stereotype.Service;

/**
 * Created by Administrator on 2018/11/2.
 */
@Service
public class LoginService {
    public String doLogin(String username, String password){
        Subject currentUser = SecurityUtils.getSubject();
        if (!currentUser.isAuthenticated()){
            UsernamePasswordToken token = new UsernamePasswordToken(username,password);
            try{
                currentUser.login(token);
                return "success";
            }catch (AuthenticationException e){
                e.printStackTrace();
            }
            return "error";
        }
        return "success";
    }
}
