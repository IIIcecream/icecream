package glodon.demo.ssm.dao.pojo;

/**
 * Created by Administrator on 2018/11/2.
 */
public class ManagerBeam {
    Integer userid;
    String username;
    String password;

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
