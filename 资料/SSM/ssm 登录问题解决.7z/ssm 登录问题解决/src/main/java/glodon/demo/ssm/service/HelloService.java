package glodon.demo.ssm.service;

import org.springframework.stereotype.Service;

/**
 * Created by Administrator on 2018/11/1.
 */
@Service
public class HelloService {
    public String SayHello(){
        return "hello";
    }
}
